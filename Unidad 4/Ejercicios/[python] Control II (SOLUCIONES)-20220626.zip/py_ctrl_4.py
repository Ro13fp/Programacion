def capicua(n):
    snum = str(abs(n))
    
    if len(snum)==1:
        return True
        
    i=0
    j=len(snum) - 1
    
    while(i<j):
        if snum[i]!=snum[j]:
            return False
        i+=1
        j-=1

    return True
