n = int(input("Introduce un número [1-10]> "))

if n<1 or n>10:
    print("Entrada no válida")
else:
    print("Tabla del", n)
    for i in range(11):
        print(f'{n} x {i} = {n*i}')
