def escalera(n):
    if n<1 or n>9:
        print("Entrada no válida")
        return
    
    for i in range(n):
        for j in range(1, i+2):
            print(j, end="")
        print()
