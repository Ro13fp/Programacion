import sys

n = int(input("Introduce un número [1-10]> "))

if n<1 or n>10:
    print("Entrada no válida")
    sys.exit()
    
i = 1
m = n*i
while m<100:
    s = str(m)
    if i>1:
        s = ", " + s
    print(s, end="")
    i += 1
    m = n*i
