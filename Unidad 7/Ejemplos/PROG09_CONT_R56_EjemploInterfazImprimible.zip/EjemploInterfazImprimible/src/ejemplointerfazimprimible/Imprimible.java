/*
 * Interfaz Imprimible
 */
package ejemplointerfazimprimible;


/**
 *
 * Interfaz Imprimible
 */
public interface Imprimible {
	String devolverContenidoString ();

}
