/*
 * Interfaz Imprimible
 */
package ejemplopolimorfismopersona;


/**
 *
 * Interfaz Imprimible
 */
public interface Imprimible {
	String devolverContenidoString ();

}
