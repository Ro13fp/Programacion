/**
 *
 * Ejemplo de clase Punto
 */

class Punto {
    // Atributos
    int x,y;

    // M�todos
    int obtenerX () { return x; }
    int obtenerY()  {return y;}
    void establecerX (int vx) { x= vx; };
    void establecerY (int vy) { y= vy; };
}